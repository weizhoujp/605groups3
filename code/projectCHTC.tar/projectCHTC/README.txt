This file contains our code running the CHTC jobs. 
If you would like to re-run the code, just run glm.sub.

glm.R-----R code for building generalized linear model. Accept one argument which is the name of the directory contains corresponding data.
glm.sh----bash script to run the R script.
glm.sub---Submit jobs to the computation center.
folder.txt---File contains names of directories containing corresponding data.
project.log---Log file of running .sub file.